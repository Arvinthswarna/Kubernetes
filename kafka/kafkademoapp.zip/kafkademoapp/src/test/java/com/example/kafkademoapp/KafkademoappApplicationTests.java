package com.example.kafkademoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkademoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
